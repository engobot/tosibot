
STATUS:**DISCONTINUED** 


Toshinou Ultra
==========
A cheat/tool/bot/whatever for a browser flash game named DarkOrbit.
It does some pretty neat stuff and is still under heavy development.
The tool was originally created by freshek, but has been modified and updated by a lot of different people
since freshek abandoned it.  
There's a **HIGH RISK OF BAN**, and i don't recommend you using it on an account you don't want to lose.


How to install/use?
----------
EN guide: https://youtu.be/sZOrfItRd2w <br />
ES guide: https://youtu.be/4kp8v413634<br />
### Chrome/Chromium/Opera
1. Download and extract it
2. Open any web proxy and locate the options
3. Enable HTTPS decryption (you maybe have to trust the certification and restart the proxy)
4. Install the addon through chrome://extensions
5. Use any web proxy to replace the main.swf and preloader.swf
6. Enjoy!

TODO:
----------
-Improve Palladium repair 
-React to enemy attacks on palladium  
-Palladium traveler if repairing on gate  
-Improve gg repair(ship can run onto npcs and die)  
-Improve npc Circle  
-Temporarily save box positions  

Issues
----------
If the tool doesn't work, try to use Private mode/Incognito.
Other situations should be reported in [issues](../../issues) (game updates are fine there too).
