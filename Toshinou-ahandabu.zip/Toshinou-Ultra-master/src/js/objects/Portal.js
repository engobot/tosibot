class Portal{
    constructor(gateId, idLinkedMap){
      this.gateId = gateId;
      this.idLinkedMap = idLinkedMap;
    }
}