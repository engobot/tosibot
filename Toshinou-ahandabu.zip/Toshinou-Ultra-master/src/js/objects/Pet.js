class Pet {
    constructor(id) {
		this.id = id;
		this.destroyed = false;
	}
}