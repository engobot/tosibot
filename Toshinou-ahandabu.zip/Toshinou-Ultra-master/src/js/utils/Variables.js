class Variables {
	static get assetCreateX() {
		return "_-I4A";
	}
	
	static get assetCreateY() {
		return "_-9S";
	}
	
	static get boxType() {
		return "_-6m";
	}
	
	static get gateId() {
		return "_-zU";
	}
	
	static get gateType() {
		return "_-Z4e";
	}
	
	static get attackerId() {
		return "_-H1q";
	}
	
	static get heroAttackedId() {
		return "_-aa";
	}
	
	static get attackHp() {
		return "_-B2d";
	}
	
	static get attackShd() {
		return "_-v3x";
	}
	
	static get heroInitMaxHp() {
		return "_-V3Y";
	}
	
	static get heroInitMaxShd() {
		return "_-D4G";
	}
	
	static get heroInitHp() {
		return "_-o1k";
	}
	
	static get heroPetId() {
		return "_-f5";
	}
	
	static get hpUpdateMaxHp() {
		return "_-J2A";
	}
	
	static get hpUpdateHp() {
		return "_-y1o";
	}
	
	static get heroUpdateShd() {
		return "_-l1B";
	}
	
	static get resource() {
		return "_-E3W";
	}
	
	static get clanDiplomacy() {
		return "_-uS";
	}
	
	static get shipDestroyedId() {
		return "_-B15";
	}
	
	static get selectMaxHp() {
		return "_-J2A";
	}
	
	static get selectMaxShd() {
		return "_-D4G";
	}
	
	static get selectHp() {
		return "_-y1o";
	}

	static get moveDuration() {
		return "_-T4N";
	}
		
	
	static get resourceType() {
		return "_-9A";
	}

	static get battlestationClanDiplomacy() {
		return "_-049"; 
	}
	

    static get attackedId() {
        return "_-VO";
    }
	
}
