class SafetyChecker {
  static check() {
    let jsCheck = JavaScriptChecker.safetyCheck();
    return jsCheck;
  }
}